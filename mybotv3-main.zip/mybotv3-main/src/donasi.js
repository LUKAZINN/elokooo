const donasi = () => { 
	return `Mau donasi agar bot bisa terus berjalan.

 فَاتَّقُوا النَّارَ وَلَوْ بِشِقِّ تَمْرَةٍ فَمَنْ لَمْ يَجِدْ فَبِكَلِمَةٍ طَيِّبَةٍ
_“jauhilah api neraka, walau hanya dengan bersedekah setengah biji kurma atau satu biji kurma(sedikit). Jika kamu tidak punya, maka bisa dengan kalimah thayyibah” [HR. Bukhari 6539, Muslim 1016]_

*Pulsa :* _085781406716_
*Dana :* _085781406716_
*OVO :* _085781406716_
*Gopay* _085781406716_`
}

exports.donasi = donasi