const imagemaker = (prefix, botName, ownerName) => {
        return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 INFORMAÇÃO DO BOT 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : LUKAZINN
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra os usuarios bloquados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostrar velocidade do bot de conexão
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuarios que estão o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 IMAGE MAKER 〉*
   ╽
   ┠≽ *${prefix}bpink* <text>
   ┃ *Desc* : Faça uma imagem BlackPink
   ┠──────────────╼
   ┠≽ *${prefix}quotemaker* <text>
   ┃ *Desc* : Imagem de fazer citações
   ┠──────────────╼
   ┠≽ *${prefix}snowwrite* <text|text>
   ┃ *Desc* : Faça a imagem do Snowwrite
   ┠──────────────╼
   ┠≽ *${prefix}3dtext* <text>
   ┃ *Desc* : Criar imagem de texto 3D
   ┠──────────────╼
   ┠≽ *${prefix}firetext* <text>
   ┃ *Desc* : Criar Imagem com Texto Fogo
   ┠──────────────╼
   ┠≽ *${prefix}glitch* <text|text>
   ┃ *Desc* : Criar Imagem com glitch
   ┠──────────────╼
   ┠≽ *${prefix}shadow* <text>
   ┃ *Desc* : Faça a imagem da sombra
   ┠──────────────╼
   ┠≽ *${prefix}burnpaper* <text>
   ┃ *Desc* : fazer queimar imagem de papel
   ┠──────────────╼
   ┠≽ *${prefix}coffee* <text>
   ┃ *Desc* : Imagem de fazer café
   ┠──────────────╼
   ┠≽ *${prefix}water* <text>
   ┃ *Desc* :  Imagem Agua
   ┠──────────────╼
   ┠≽ *${prefix}lovepaper* <text>
   ┃ *Desc* : Imagem de papel de fazer amor
   ┠──────────────╼
   ┠≽ *${prefix}woodblock* <text>
   ┃ *Desc* : Imagem de Bloco de Madeira
   ┠──────────────╼
   ┠≽ *${prefix}qowheart* <text>
   ┃ *Desc* : Faça citações na imagem dos corações de madeira
   ┠──────────────╼
   ┠≽ *${prefix}mutgrass* <text>
   ┃ *Desc* : Faça uma mensagem sob a imagem da grama
   ┠──────────────╼
   ┠≽ *${prefix}undergocean* <text>
   ┃ *Desc* : fazer mensagem imagem do oceano subterrâneo
   ┠──────────────╼
   ┠≽ *${prefix}woodenboards* <text>
   ┃ *Desc* : Imagem de Tábuas de Madeira
   ┠──────────────╼
   ┠≽ *${prefix}wolfmetal* <text>
   ┃ *Desc* : Faça metal de lobo
   ┠──────────────╼
   ┠≽ *${prefix}metalictglow* <text>
   ┃ *Desc* : Imagem de tornar o texto metálico brilhante
   ┠──────────────╼
   ┠≽ *${prefix}8bit* <text|text>
   ┃ *Desc* : Imagem de 8 bits
   ┠──────────────╼
   ┠≽ *${prefix}herrypotter* <text>
   ┃ *Desc* : Faça a imagem de Harry Potter
   ╿ *LUKAZINN*,
   ╰╼≽ *Developer © LUKAZINN`
}
exports.imagemaker = imagemaker
