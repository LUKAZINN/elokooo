const group = (prefix, botName, ownerName) => {
        return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 BOT INFO 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra os usuarios bloquados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostrar velocidade do bot de conexão
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuarios que estão o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 GROUPO 〉*
   ╽
   ┠≽ *${prefix}opengc*
   ┃ *Desc* : Grupo de Abertura
   ┠──────────────╼
   ┠≽ *${prefix}closegc*
   ┃ *Desc* : Fechando o Grupo
   ┠──────────────╼
   ┠≽ *${prefix}hidetag*
   ┃ *Desc* : Ocultar mensagem de tag para todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}setname* <text>
   ┃ *Desc* : Mudar nome do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}setdesc* <teks>
   ┃ *Desc* : Mudar Descrição do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}promote* <@tag>
   ┃ *Desc* : Promover para Administrador do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}demote* <@tag>
   ┃ *Desc* : Demitir Administrador para membro Comum
   ┠──────────────╼
   ┠≽ *${prefix}tagall*
   ┃ *Desc* : Mencione todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}tagall2*
   ┃ *Desc* : Mencione todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}tagall3*
   ┃ *Desc* : Mencione todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}tagall4*
   ┃ *Desc* : Mencione todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}tagall5*
   ┃ *Desc* : Mencione todos os membros
   ┠──────────────╼
   ┠≽ *${prefix}add* <558197558929>
   ┃ *Desc* : Adicionar Membros 
   ┠──────────────╼
   ┠≽ *${prefix}kick* <@tag>
   ┃ *Desc* : Expulsar Membros do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}listadmins*
   ┃ *Desc* : Lista de Administradores do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}listgroup*
   ┃ *Desc* : Mostrar lista de todos os bots do grupo
   ┠──────────────╼
   ┠≽ *${prefix}linkgroup*
   ┃ *Desc* : Mostra Link do Grupo
   ┠──────────────╼
   ┠≽ *${prefix}join* <link_groupo>
   ┃ *Desc* : Adicionar bot para se juntar ao seu grupo
   ┠──────────────╼
   ┠≽ *${prefix}leave*
   ┃ *Desc* : Diga ao bot para sair do grupo
   ┠──────────────╼
   ┠≽ *${prefix}welcome* <1/0>
   ┃ *Desc* : Ativar / Desativar Comando de Boas Vindas
   ┠──────────────╼
   ┠≽ *${prefix}antilink* <1/0>
   ┃ *Desc* : Ativar / Desativar Enviar Links
   ┠──────────────╼
   ┠≽ *${prefix}nsfw* <1/0>
   ┃ *Desc* : Ativar / Desativar NSFW 
   ┠──────────────╼
   ┠≽ *${prefix}delete*
   ┃ *Desc* : Deletar Mensagem do Bot
   ┠──────────────╼
   ┠≽ *${prefix}simih* <1/0>
   ┃ *Desc* : Ativar / Desativar o Simih 
   ┠──────────────╼
   ┠≽ *${prefix}leaderboard* 
   ┃ *Desc* : Ainda testando
   ┠──────────────╼
   ┠≽ *${prefix}tagme*
   ┃ *Desc* : Mensacionar voçê
   ┠──────────────╼
   ┠≽ *${prefix}ownergroup*
   ┃ *Desc* : Mostra quem é o proprietário do grupo
   ╿ *𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆*,
   ╰╼≽ *Developer © 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆`
}
exports.group = group
