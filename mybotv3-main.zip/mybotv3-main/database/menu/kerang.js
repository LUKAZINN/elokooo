const kerang = (prefix, botName, ownerName) => {
	return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 INFORMAÇÕES DO BOT 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : LUKAZINN
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra os usuarios bloquados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostrar velocidade do bot de conexão
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuarios que estão o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
╿ *LUKAZINN*,
╰╼≽ *Developer © LUKAZINN`
}
exports.kerang = kerang
