const education = (prefix, botName, ownerName) => {
	return `
┏ *〈 ${botName} 〉*
╿
┷┯ *〈 INFORMAÇÕES DO BOT 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 ABOUT 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Mostra informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra usuarios bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostra conexão do Bot
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuariosque usam o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 EDUCAÇÃO 〉*
   ╽
   ┠≽ *${prefix}wiki* <query>
   ┃ *Desc* : Pesquisa de acordo com a Wikipedia [indo]
   ┠──────────────╼
   ┠≽ *${prefix}wikien* <query>
   ┃ *Desc* : Pesquisa de acordo com a Wikipedia [inglês]
   ┠──────────────╼
   ┠≽ *${prefix}nulis* <text>
   ┃ *Desc* : Escreva um texto no livro
   ┠──────────────╼
   ┠≽ *${prefix}map* <localização>
   ┃ *Desc* : Mostrar mapa na localização
   ┠──────────────╼
   ┠≽ *${prefix}quotes*
   ┃ *Desc* : Envie uma cotação aleatória
   ┠──────────────╼
   ┠≽ *${prefix}quotes2*
   ┃ *Desc* : Envie uma cotação aleatória 2
   ┠──────────────╼
   ┠≽ *${prefix}tafsirmimpi* <dream>
   ┃ *Desc* : Envie uma interpretação do sonho
   ┠──────────────╼
   ┠≽ *${prefix}translate* <linguagem_code>|<text>
   ┃ *Desc* : Traduzindo uma palavra
   ┠──────────────╼
   ┠≽ *${prefix}artinama* <name>
   ┃ *Desc* : Interpretar nomes
   ╿ *𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆*,
   ╰╼≽ *Developer © 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆`
}
exports.education = education
