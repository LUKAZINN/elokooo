const fun = (prefix, botName, ownerName) => {
        return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 INFORMAÇÃO DO BOT 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra os usuarios bloquados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostrar velocidade do bot de conexão
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuarios que estão o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 FUN 〉*
   ╽
   ┠≽ *${prefix}alay* <text>
   ┃ *Desc* : Mudando Palavras em Alay
   ┠──────────────╼
   ┠≽ *${prefix}tebakgambar* <text>
   ┃ *Desc* : Jogo
   ┠──────────────╼
   ┠≽ *${prefix}slap* <text>
   ┃ *Desc* : Toxico
   ┠──────────────╼
   ┠≽ *${prefix}persenbucin*
   ┃ *Desc* : Verifica a porcentagem de Bucin
   ┠──────────────╼
   ┠≽ *${prefix}persengay*
   ┃ *Desc* : Verifica a porcentagem que voçê é gay
   ┠──────────────╼
   ┠≽ *${prefix}rate*
   ┃ *Desc* : Verifica sua taxa
   ┠──────────────╼
   ┠≽ *${prefix}gantengcek*
   ┃ *Desc* : Veriica o quao bonito
   ┠──────────────╼
   ┠≽ *${prefix}cantikcek*
   ┃ *Desc* : Que bonito
   ┠──────────────╼
   ┠≽ *${prefix}watak*
   ┃ *Desc* : Transmitindo personagens ao acaso
   ┠──────────────╼
   ┠≽ *${prefix}hobby*
   ┃ *Desc* : Envio aleatório de hobbies
   ┠──────────────╼
   ┠≽ *${prefix}simi* <text>
   ┃ *Desc* : falar com o simi
   ╿ *𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆*,
   ╰╼≽ *Developer © 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆`
}
exports.fun = fun
