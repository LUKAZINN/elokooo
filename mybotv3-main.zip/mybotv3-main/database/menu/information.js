const information = (prefix, botName, ownerName) => {
        return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 INFORMAÇÕES DO BOT 〉*
   ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : LUKAZINN
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra os usuarios bloquados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostrar velocidade do bot de conexão
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuarios que estão o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 INFORMATION 〉*
   ╽
   ┠≽ *${prefix}bahasa*
   ┃ *Desc* : Enviar código de idioma
   ┠──────────────╼
   ┠≽ *${prefix}kodenegara*
   ┃ *Desc* : Enviar código do país
   ┠──────────────╼
   ┠≽ *${prefix}kbbi* <question>
   ┃ *Desc* : Perguntando ao KBBI
   ┠──────────────╼
   ┠≽ *${prefix}fakta*
   ┃ *Desc* : Envie um fato aleatório
   ┠──────────────╼
   ┠≽ *${prefix}jadwaltv*
   ┃ *Desc* : Testando
   ┠──────────────╼
   ┠≽ *${prefix}katabijak*
   ┃ *Desc* : Citações Aleatórias
   ┠──────────────╼
   ┠≽ *${prefix}faktaunik*
   ┃ *Desc* : Envie um fato aleatório
   ┠──────────────╼
   ┠≽ *${prefix}infocuaca* <area>
   ┃ *Desc* : Enviar informações meteorológicas
   ┠──────────────╼
   ┠≽ *${prefix}infogempa*
   ┃ *Desc* : Enviando informações sobre terremotos
   ┠──────────────╼
   ┠≽ *${prefix}covidcountry* <country>
   ┃ *Desc* : Envio de informações para Covid-19
   ╿ *LUKAZINN*,
   ╰╼≽ *Developer © LUKAZINN`
}
exports.information = information
