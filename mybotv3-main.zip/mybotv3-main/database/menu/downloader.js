const downloader = (prefix, botName, ownerName) => {
	return `
┏ *〈 LUKABOT 〉*
╿
┷┯ *〈 INFORMAÇÕES DO BOT 〉*
    ╽
   ┠≽ *Prefix* : 「  ${prefix}  」
   ┠≽ *desenvolvedor* : 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆
   ┠≽ *Version* : 「  2.0.0  」
   ╿
┯┷ *〈 OUTROS 〉*
╽
┠≽ *${prefix}info*
┃ *Desc* : Mostra informações do Bot
┠──────────────╼
┠≽ *${prefix}blocklist*
┃ *Desc* : Mostra usuarios bloqueados
┠──────────────╼
┠≽ *${prefix}chatlist*
┃ *Desc* : Mostra todos os usuarios
┠──────────────╼
┠≽ *${prefix}ping*
┃ *Desc* : Mostra conexão do Bot
┠──────────────╼
┠≽ *${prefix}totaluser*
┃ *Desc* : Mostra todos os usuariosque usam o Bot
┠──────────────╼
┠≽ *${prefix}request*
┃ *Desc* : Solicitar Fiture ao Proprietário do Bot
┠──────────────╼
┠≽ *${prefix}bugreport* <text>
┃ *Desc* : Reportar bug ao desenvolvedor do Bot.
╿
┷┯ *〈 DOWNLOADER 〉*
   ╽
   ┠≽ *${prefix}pinterest* <query>
   ┃ *Desc* : Baixar imagem do Pinterest
   ┠──────────────╼
   ┠≽ *${prefix}ytmp3* <linkyt>
   ┃ *Desc* : Baixe o vídeo do Youtube para mp3
   ┠──────────────╼
   ┠≽ *${prefix}ytmp4* <linkyt>
   ┃ *Desc* : Baixe o vídeo do Youtube
   ┠──────────────╼
   ┠≽ *${prefix}fb* <linkfb>
   ┃ *Desc* : Baixe o vídeo do Facebook
   ┠──────────────╼
   ┠≽ *${prefix}ig* <linkig>
   ┃ *Desc* : Download Instagram Video
   ┠──────────────╼
   ┠≽ *${prefix}igstory* <linkigstory>
   ┃ *Desc* : Baixe o vídeo instantâneo
   ┠──────────────╼
   ┠≽ *${prefix}happymod* <game>
   ┃ *Desc* : Downlaod Jogo Mod
   ┠──────────────╼
   ┠≽ *${prefix}moddroid* <game>
   ┃ *Desc* : Download Jogo Mod
   ┠──────────────╼
   ┠≽ *${prefix}playstore* <query>
   ┃ *Desc* : Baixar o jogo da Playtore
   ┠──────────────╼
   ┠≽ *${prefix}tiktok* <linktiktok>
   ┃ *Desc* : Download Video do TikTok
   ╿ *𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆*,
   ╰╼≽ *Developer © 𝑳𝑼𝑲𝑨𝒁𝑰𝑵𝑵☆`
}
exports.downloader = downloader
